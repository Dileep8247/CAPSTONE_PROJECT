import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent implements OnInit {
  submitted: boolean = false;
  constructor(private s1:StudentService) { }

  data:any;

  ngOnInit(): void {
  let response = this.s1.viewservice();
  response.subscribe((data1: any)=>this.data=data1)

  }
  deletedata(deleteform:{value:any;})
  {
    this.submitted =true;
    return this.s1.deleteservice(deleteform.value).subscribe();
  }


}
