import { Component } from '@angular/core';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent {

  data:any;
  constructor(private s1:StudentService) { }

  ngOnInit(): void {
  let response = this.s1.viewservice();
  response.subscribe((data1: any)=>this.data=data1)

  }
}
