import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-insert',
  templateUrl: './insert.component.html',
  styleUrls: ['./insert.component.css']
})
export class InsertComponent implements OnInit {

  constructor(private s1:StudentService) { }
  data:any;
  submitted = false;
  ngOnInit(): void {
    let response = this.s1.viewservice();
    response.subscribe((data1: any)=>this.data=data1)
  
    }

  insertdata(insertform:{value:any;})
  {
    this.submitted = true;
    return this.s1.insertservice(insertform.value).subscribe();
    
  }
}
